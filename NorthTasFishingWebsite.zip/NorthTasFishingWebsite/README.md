
# North Tasmania Fishing Charters

Welcome to the official website repository for **North Tasmania Fishing Charters**. We offer guided fishing adventures in the scenic Tamar River Estuary, Tasmania, led by experienced local skipper **Adam Cousens** aboard our charter vessel, the **Manta Ray Mojo**.

## 🌊 About Us

Based in **Beauty Point, Tasmania**, we provide private and small group fishing charters. Whether you're a local or a visitor, you'll experience the best the Tamar River has to offer with Adam's expert knowledge of the region.

## 🎣 Pricing

- Half Day Fishing (1 person, private): **$400**
- 2 People: **$650**
- 3 People: **$750**
- 4 People: **$850**

## 📍 Contact Information

- **Location:** Beauty Point, TAS 7270  
- **Phone:** [0487 559 772](tel:0487559772)  
- **Facebook:** [North Tasmania Fishing Charters](https://facebook.com/NorthTasmaniaFishingCharters)

## 📸 Media Gallery

Photos and videos of our charters are available in the `images/` and `videos/` folders.

## 🌐 Live Site

Once published via GitHub Pages, the site can be viewed here:  
`https://your-username.github.io/north-tasmania-fishing-charters`

## 🚀 Getting Started

To clone and run locally:

```bash
git clone https://github.com/your-username/north-tasmania-fishing-charters.git
cd north-tasmania-fishing-charters
```

Open `index.html` in your browser to view the site.

## 🛠 Folder Structure

```
north-tasmania-fishing-charters/
├── index.html
├── styles.css
├── README.md
├── images/
│   ├── gallery1.jpg
│   └── gallery2.jpg
├── videos/
│   └── trip1.mp4
```

## 📄 License

This project is open source and free to use for educational and personal promotion purposes.
